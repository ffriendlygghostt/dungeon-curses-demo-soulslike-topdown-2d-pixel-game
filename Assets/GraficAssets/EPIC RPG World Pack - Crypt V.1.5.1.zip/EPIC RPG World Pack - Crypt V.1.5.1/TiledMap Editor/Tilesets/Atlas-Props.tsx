<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas-Props" tilewidth="32" tileheight="32" tilecount="828" columns="36">
 <image source="../../Props/Atlas-Props.png" width="1152" height="736"/>
</tileset>
