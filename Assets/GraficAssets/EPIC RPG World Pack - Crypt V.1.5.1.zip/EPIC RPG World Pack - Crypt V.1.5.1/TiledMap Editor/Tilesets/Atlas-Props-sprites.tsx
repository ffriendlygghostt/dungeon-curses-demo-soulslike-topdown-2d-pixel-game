<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas-Props-sprites" tilewidth="128" tileheight="128" tilecount="388" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 1.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 2.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 3.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 4.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 5.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 6.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 7.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 8.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 9.png"/>
 </tile>
 <tile id="9">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 10.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 11.png"/>
 </tile>
 <tile id="11">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 12.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 13.png"/>
 </tile>
 <tile id="13">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 14.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 15.png"/>
 </tile>
 <tile id="15">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 16.png"/>
 </tile>
 <tile id="16">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 17.png"/>
 </tile>
 <tile id="17">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/banner - bigger - 18.png"/>
 </tile>
 <tile id="18">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 1.png"/>
 </tile>
 <tile id="19">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 2.png"/>
 </tile>
 <tile id="20">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 3.png"/>
 </tile>
 <tile id="21">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 4.png"/>
 </tile>
 <tile id="22">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 5.png"/>
 </tile>
 <tile id="23">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 6.png"/>
 </tile>
 <tile id="24">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 7.png"/>
 </tile>
 <tile id="25">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 8.png"/>
 </tile>
 <tile id="26">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 9.png"/>
 </tile>
 <tile id="27">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 10.png"/>
 </tile>
 <tile id="28">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 11.png"/>
 </tile>
 <tile id="29">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 12.png"/>
 </tile>
 <tile id="30">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 13.png"/>
 </tile>
 <tile id="31">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 14.png"/>
 </tile>
 <tile id="32">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 15.png"/>
 </tile>
 <tile id="33">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 16.png"/>
 </tile>
 <tile id="34">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 17.png"/>
 </tile>
 <tile id="35">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/banner 18.png"/>
 </tile>
 <tile id="36">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/bench horizontal 2.png"/>
 </tile>
 <tile id="37">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/bench horizontal.png"/>
 </tile>
 <tile id="38">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/bench vertical 2.png"/>
 </tile>
 <tile id="39">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/bench vertical.png"/>
 </tile>
 <tile id="40">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 1.png"/>
 </tile>
 <tile id="41">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 2.png"/>
 </tile>
 <tile id="42">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 3.png"/>
 </tile>
 <tile id="43">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 4.png"/>
 </tile>
 <tile id="44">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 5.png"/>
 </tile>
 <tile id="45">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 6.png"/>
 </tile>
 <tile id="46">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 7.png"/>
 </tile>
 <tile id="47">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 8.png"/>
 </tile>
 <tile id="48">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 9.png"/>
 </tile>
 <tile id="49">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 10.png"/>
 </tile>
 <tile id="50">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 11.png"/>
 </tile>
 <tile id="51">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 12.png"/>
 </tile>
 <tile id="52">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 13.png"/>
 </tile>
 <tile id="53">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 14.png"/>
 </tile>
 <tile id="54">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 15.png"/>
 </tile>
 <tile id="55">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 16.png"/>
 </tile>
 <tile id="56">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 17.png"/>
 </tile>
 <tile id="57">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 18.png"/>
 </tile>
 <tile id="58">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 19.png"/>
 </tile>
 <tile id="59">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 20.png"/>
 </tile>
 <tile id="60">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 21.png"/>
 </tile>
 <tile id="61">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 22.png"/>
 </tile>
 <tile id="62">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 23.png"/>
 </tile>
 <tile id="63">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 24.png"/>
 </tile>
 <tile id="64">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 25.png"/>
 </tile>
 <tile id="65">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 26.png"/>
 </tile>
 <tile id="66">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 27.png"/>
 </tile>
 <tile id="67">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 28.png"/>
 </tile>
 <tile id="68">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 29.png"/>
 </tile>
 <tile id="69">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 30.png"/>
 </tile>
 <tile id="70">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 31.png"/>
 </tile>
 <tile id="71">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 32.png"/>
 </tile>
 <tile id="72">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 33.png"/>
 </tile>
 <tile id="73">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 34.png"/>
 </tile>
 <tile id="74">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 35.png"/>
 </tile>
 <tile id="75">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 36.png"/>
 </tile>
 <tile id="76">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 37.png"/>
 </tile>
 <tile id="77">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 38.png"/>
 </tile>
 <tile id="78">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 39.png"/>
 </tile>
 <tile id="79">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 40.png"/>
 </tile>
 <tile id="80">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 41.png"/>
 </tile>
 <tile id="81">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 42.png"/>
 </tile>
 <tile id="82">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 43.png"/>
 </tile>
 <tile id="83">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 44.png"/>
 </tile>
 <tile id="84">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 1 - 45.png"/>
 </tile>
 <tile id="85">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 1.png"/>
 </tile>
 <tile id="86">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 2.png"/>
 </tile>
 <tile id="87">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 3.png"/>
 </tile>
 <tile id="88">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 4.png"/>
 </tile>
 <tile id="89">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 5.png"/>
 </tile>
 <tile id="90">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 6.png"/>
 </tile>
 <tile id="91">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 7.png"/>
 </tile>
 <tile id="92">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 8.png"/>
 </tile>
 <tile id="93">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 9.png"/>
 </tile>
 <tile id="94">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 10.png"/>
 </tile>
 <tile id="95">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 11.png"/>
 </tile>
 <tile id="96">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 12.png"/>
 </tile>
 <tile id="97">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 13.png"/>
 </tile>
 <tile id="98">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 14.png"/>
 </tile>
 <tile id="99">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 15.png"/>
 </tile>
 <tile id="100">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 16.png"/>
 </tile>
 <tile id="101">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 17.png"/>
 </tile>
 <tile id="102">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 18.png"/>
 </tile>
 <tile id="103">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 19.png"/>
 </tile>
 <tile id="104">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 20.png"/>
 </tile>
 <tile id="105">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 21.png"/>
 </tile>
 <tile id="106">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 22.png"/>
 </tile>
 <tile id="107">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 23.png"/>
 </tile>
 <tile id="108">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/bones - color scheme 2 - 24.png"/>
 </tile>
 <tile id="109">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/book - closed 1.png"/>
 </tile>
 <tile id="110">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/book - closed 2.png"/>
 </tile>
 <tile id="111">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/book - open.png"/>
 </tile>
 <tile id="112">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/book - support 1.png"/>
 </tile>
 <tile id="113">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/book - support 2.png"/>
 </tile>
 <tile id="114">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/book - support 3.png"/>
 </tile>
 <tile id="115">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candelabrum 1.png"/>
 </tile>
 <tile id="116">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candelabrum 2.png"/>
 </tile>
 <tile id="117">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candelabrum 3.png"/>
 </tile>
 <tile id="118">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candelabrum 4.png"/>
 </tile>
 <tile id="119">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/candle 1.png"/>
 </tile>
 <tile id="120">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/candle 2.png"/>
 </tile>
 <tile id="121">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/candle 3.png"/>
 </tile>
 <tile id="122">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/candle 4.png"/>
 </tile>
 <tile id="123">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin - horizontal - 1.png"/>
 </tile>
 <tile id="124">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin - horizontal - 2.png"/>
 </tile>
 <tile id="125">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin - horizontal - 3.png"/>
 </tile>
 <tile id="126">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin - horizontal - 4.png"/>
 </tile>
 <tile id="127">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin - horizontal - 5.png"/>
 </tile>
 <tile id="128">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 1.png"/>
 </tile>
 <tile id="129">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 2.png"/>
 </tile>
 <tile id="130">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 3.png"/>
 </tile>
 <tile id="131">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 4.png"/>
 </tile>
 <tile id="132">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 5.png"/>
 </tile>
 <tile id="133">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin - vertical - 6.png"/>
 </tile>
 <tile id="134">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 1.png"/>
 </tile>
 <tile id="135">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 2.png"/>
 </tile>
 <tile id="136">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 3.png"/>
 </tile>
 <tile id="137">
  <image width="95" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 4.png"/>
 </tile>
 <tile id="138">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 5.png"/>
 </tile>
 <tile id="139">
  <image width="96" height="64" source="../../Props/atlas props - individual sprites/coffin lid - horizontal - 6.png"/>
 </tile>
 <tile id="140">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 1.png"/>
 </tile>
 <tile id="141">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 2.png"/>
 </tile>
 <tile id="142">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 3.png"/>
 </tile>
 <tile id="143">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 4.png"/>
 </tile>
 <tile id="144">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 5.png"/>
 </tile>
 <tile id="145">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 6.png"/>
 </tile>
 <tile id="146">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 7.png"/>
 </tile>
 <tile id="147">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 8.png"/>
 </tile>
 <tile id="148">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 9.png"/>
 </tile>
 <tile id="149">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 10.png"/>
 </tile>
 <tile id="150">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 11.png"/>
 </tile>
 <tile id="151">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 12.png"/>
 </tile>
 <tile id="152">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 13.png"/>
 </tile>
 <tile id="153">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 14.png"/>
 </tile>
 <tile id="154">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 15.png"/>
 </tile>
 <tile id="155">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/coffin lid - vertical - 16.png"/>
 </tile>
 <tile id="156">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/cross 1.png"/>
 </tile>
 <tile id="157">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/cross 2.png"/>
 </tile>
 <tile id="158">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/cross 3.png"/>
 </tile>
 <tile id="159">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/cross with support 1.png"/>
 </tile>
 <tile id="160">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/cross with support 2.png"/>
 </tile>
 <tile id="161">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/cross with support 3.png"/>
 </tile>
 <tile id="162">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/cross with support 4.png"/>
 </tile>
 <tile id="163">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/cross with support 5.png"/>
 </tile>
 <tile id="164">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/Slice 69.png"/>
 </tile>
 <tile id="165">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/Slice 160.png"/>
 </tile>
 <tile id="166">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/statue 1.png"/>
 </tile>
 <tile id="167">
  <image width="32" height="64" source="../../Props/atlas props - individual sprites/statue 2.png"/>
 </tile>
 <tile id="168">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/statue 3.png"/>
 </tile>
 <tile id="169">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/statue 4.png"/>
 </tile>
 <tile id="170">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/statue 5.png"/>
 </tile>
 <tile id="171">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/statue 6.png"/>
 </tile>
 <tile id="172">
  <image width="64" height="32" source="../../Props/atlas props - individual sprites/statue and cross support 1.png"/>
 </tile>
 <tile id="173">
  <image width="64" height="32" source="../../Props/atlas props - individual sprites/statue and cross support 2.png"/>
 </tile>
 <tile id="174">
  <image width="64" height="32" source="../../Props/atlas props - individual sprites/statue and cross support 3.png"/>
 </tile>
 <tile id="175">
  <image width="64" height="32" source="../../Props/atlas props - individual sprites/statue and cross support 4.png"/>
 </tile>
 <tile id="176">
  <image width="128" height="32" source="../../Props/atlas props - individual sprites/tissue - horizontal - 1.png"/>
 </tile>
 <tile id="177">
  <image width="128" height="32" source="../../Props/atlas props - individual sprites/tissue - horizontal - 2.png"/>
 </tile>
 <tile id="178">
  <image width="128" height="32" source="../../Props/atlas props - individual sprites/tissue - horizontal - 3.png"/>
 </tile>
 <tile id="179">
  <image width="128" height="32" source="../../Props/atlas props - individual sprites/tissue - horizontal - 4.png"/>
 </tile>
 <tile id="180">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/tissue -vertical - 1.png"/>
 </tile>
 <tile id="181">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/tissue -vertical - 2.png"/>
 </tile>
 <tile id="182">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/tissue -vertical - 3.png"/>
 </tile>
 <tile id="183">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/tissue -vertical - 4.png"/>
 </tile>
 <tile id="184">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/torch support front.png"/>
 </tile>
 <tile id="185">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/torch support sideways.png"/>
 </tile>
 <tile id="186">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/trap - projectile launcher 1.png"/>
 </tile>
 <tile id="187">
  <image width="32" height="96" source="../../Props/atlas props - individual sprites/trap - projectile launcher 2.png"/>
 </tile>
 <tile id="188">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - projectile launcher 3.png"/>
 </tile>
 <tile id="189">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/trap - projectile launcher 4.png"/>
 </tile>
 <tile id="190">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/trap - projectile launcher 5.png"/>
 </tile>
 <tile id="191">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - projectile launcher 6.png"/>
 </tile>
 <tile id="192">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - projectile launcher 7.png"/>
 </tile>
 <tile id="193">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - projectile launcher 8.png"/>
 </tile>
 <tile id="194">
  <image width="96" height="32" source="../../Props/atlas props - individual sprites/trap - saw trail.png"/>
 </tile>
 <tile id="195">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - off - 1.png"/>
 </tile>
 <tile id="196">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - off - 2.png"/>
 </tile>
 <tile id="197">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - off - 3.png"/>
 </tile>
 <tile id="198">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - off - 4.png"/>
 </tile>
 <tile id="199">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - on - 1.png"/>
 </tile>
 <tile id="200">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - on - 2.png"/>
 </tile>
 <tile id="201">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - on - 3.png"/>
 </tile>
 <tile id="202">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/trap - spike - on - 4.png"/>
 </tile>
 <tile id="203">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 1.png"/>
 </tile>
 <tile id="204">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 2.png"/>
 </tile>
 <tile id="205">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 4.png"/>
 </tile>
 <tile id="206">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 5.png"/>
 </tile>
 <tile id="207">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 6.png"/>
 </tile>
 <tile id="208">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 7.png"/>
 </tile>
 <tile id="209">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 8.png"/>
 </tile>
 <tile id="210">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 9.png"/>
 </tile>
 <tile id="211">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 10.png"/>
 </tile>
 <tile id="212">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 1 - 11.png"/>
 </tile>
 <tile id="213">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 1.png"/>
 </tile>
 <tile id="214">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 2.png"/>
 </tile>
 <tile id="215">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 3.png"/>
 </tile>
 <tile id="216">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 4.png"/>
 </tile>
 <tile id="217">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 5.png"/>
 </tile>
 <tile id="218">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 6.png"/>
 </tile>
 <tile id="219">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 7.png"/>
 </tile>
 <tile id="220">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 8.png"/>
 </tile>
 <tile id="221">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 9.png"/>
 </tile>
 <tile id="222">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 10.png"/>
 </tile>
 <tile id="223">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 2 - 11.png"/>
 </tile>
 <tile id="224">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 1.png"/>
 </tile>
 <tile id="225">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 2.png"/>
 </tile>
 <tile id="226">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 3.png"/>
 </tile>
 <tile id="227">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 4.png"/>
 </tile>
 <tile id="228">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 5.png"/>
 </tile>
 <tile id="229">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 6.png"/>
 </tile>
 <tile id="230">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 7.png"/>
 </tile>
 <tile id="231">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 8.png"/>
 </tile>
 <tile id="232">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 9.png"/>
 </tile>
 <tile id="233">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 10.png"/>
 </tile>
 <tile id="234">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 3 - 11.png"/>
 </tile>
 <tile id="235">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 1.png"/>
 </tile>
 <tile id="236">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 2.png"/>
 </tile>
 <tile id="237">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 3.png"/>
 </tile>
 <tile id="238">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 4.png"/>
 </tile>
 <tile id="239">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 5.png"/>
 </tile>
 <tile id="240">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 6.png"/>
 </tile>
 <tile id="241">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 7.png"/>
 </tile>
 <tile id="242">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 8.png"/>
 </tile>
 <tile id="243">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 9.png"/>
 </tile>
 <tile id="244">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 10.png"/>
 </tile>
 <tile id="245">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 4 - 11.png"/>
 </tile>
 <tile id="246">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 1.png"/>
 </tile>
 <tile id="247">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 2.png"/>
 </tile>
 <tile id="248">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 3.png"/>
 </tile>
 <tile id="249">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 4.png"/>
 </tile>
 <tile id="250">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 5.png"/>
 </tile>
 <tile id="251">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 6.png"/>
 </tile>
 <tile id="252">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 7.png"/>
 </tile>
 <tile id="253">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 8.png"/>
 </tile>
 <tile id="254">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 9.png"/>
 </tile>
 <tile id="255">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 10.png"/>
 </tile>
 <tile id="256">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 5 - 11.png"/>
 </tile>
 <tile id="257">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 1.png"/>
 </tile>
 <tile id="258">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 2.png"/>
 </tile>
 <tile id="259">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 3.png"/>
 </tile>
 <tile id="260">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 4.png"/>
 </tile>
 <tile id="261">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 5.png"/>
 </tile>
 <tile id="262">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 6.png"/>
 </tile>
 <tile id="263">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 7.png"/>
 </tile>
 <tile id="264">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 8.png"/>
 </tile>
 <tile id="265">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 9.png"/>
 </tile>
 <tile id="266">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 10.png"/>
 </tile>
 <tile id="267">
  <image width="32" height="32" source="../../Props/atlas props - individual sprites/vase color scheme 6 - 11.png"/>
 </tile>
 <tile id="268">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 1.png"/>
 </tile>
 <tile id="269">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 2.png"/>
 </tile>
 <tile id="270">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 3.png"/>
 </tile>
 <tile id="271">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 4.png"/>
 </tile>
 <tile id="272">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 5.png"/>
 </tile>
 <tile id="273">
  <image width="64" height="96" source="../../Props/atlas props - individual sprites/statue with support 6.png"/>
 </tile>
 <tile id="274">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_1.png"/>
  <animation>
   <frame tileid="274" duration="100"/>
   <frame tileid="275" duration="100"/>
   <frame tileid="276" duration="100"/>
   <frame tileid="277" duration="100"/>
   <frame tileid="278" duration="100"/>
   <frame tileid="279" duration="100"/>
   <frame tileid="280" duration="100"/>
   <frame tileid="281" duration="100"/>
  </animation>
 </tile>
 <tile id="275">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_2.png"/>
 </tile>
 <tile id="276">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_3.png"/>
 </tile>
 <tile id="277">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_4.png"/>
 </tile>
 <tile id="278">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_5.png"/>
 </tile>
 <tile id="279">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_6.png"/>
 </tile>
 <tile id="280">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_7.png"/>
 </tile>
 <tile id="281">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning_8.png"/>
 </tile>
 <tile id="282">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_1.png"/>
  <animation>
   <frame tileid="282" duration="100"/>
   <frame tileid="283" duration="100"/>
   <frame tileid="284" duration="100"/>
   <frame tileid="285" duration="100"/>
   <frame tileid="286" duration="100"/>
   <frame tileid="287" duration="100"/>
   <frame tileid="288" duration="100"/>
   <frame tileid="289" duration="100"/>
   <frame tileid="290" duration="100"/>
   <frame tileid="291" duration="100"/>
   <frame tileid="292" duration="100"/>
   <frame tileid="293" duration="100"/>
  </animation>
 </tile>
 <tile id="283">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_2.png"/>
 </tile>
 <tile id="284">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_3.png"/>
 </tile>
 <tile id="285">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_4.png"/>
 </tile>
 <tile id="286">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_5.png"/>
 </tile>
 <tile id="287">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_6.png"/>
 </tile>
 <tile id="288">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_7.png"/>
 </tile>
 <tile id="289">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_8.png"/>
 </tile>
 <tile id="290">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_9.png"/>
 </tile>
 <tile id="291">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_10.png"/>
 </tile>
 <tile id="292">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_11.png"/>
 </tile>
 <tile id="293">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_burning2_12.png"/>
 </tile>
 <tile id="294">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_1.png"/>
  <animation>
   <frame tileid="294" duration="100"/>
   <frame tileid="295" duration="100"/>
   <frame tileid="296" duration="100"/>
   <frame tileid="297" duration="100"/>
   <frame tileid="298" duration="100"/>
   <frame tileid="299" duration="100"/>
   <frame tileid="300" duration="100"/>
   <frame tileid="301" duration="100"/>
   <frame tileid="302" duration="100"/>
   <frame tileid="303" duration="100"/>
   <frame tileid="304" duration="100"/>
   <frame tileid="305" duration="100"/>
   <frame tileid="306" duration="100"/>
   <frame tileid="307" duration="100"/>
   <frame tileid="308" duration="100"/>
   <frame tileid="309" duration="100"/>
   <frame tileid="310" duration="100"/>
   <frame tileid="311" duration="100"/>
  </animation>
 </tile>
 <tile id="295">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_2.png"/>
 </tile>
 <tile id="296">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_3.png"/>
 </tile>
 <tile id="297">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_4.png"/>
 </tile>
 <tile id="298">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_5.png"/>
 </tile>
 <tile id="299">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_6.png"/>
 </tile>
 <tile id="300">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_7.png"/>
 </tile>
 <tile id="301">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_8.png"/>
 </tile>
 <tile id="302">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_9.png"/>
 </tile>
 <tile id="303">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_10.png"/>
 </tile>
 <tile id="304">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_11.png"/>
 </tile>
 <tile id="305">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_12.png"/>
 </tile>
 <tile id="306">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_13.png"/>
 </tile>
 <tile id="307">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_14.png"/>
 </tile>
 <tile id="308">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_15.png"/>
 </tile>
 <tile id="309">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_16.png"/>
 </tile>
 <tile id="310">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_17.png"/>
 </tile>
 <tile id="311">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle_smoking_18.png"/>
 </tile>
 <tile id="312">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_1.png"/>
  <animation>
   <frame tileid="312" duration="100"/>
   <frame tileid="313" duration="100"/>
   <frame tileid="314" duration="100"/>
   <frame tileid="315" duration="100"/>
   <frame tileid="316" duration="100"/>
   <frame tileid="317" duration="100"/>
   <frame tileid="318" duration="100"/>
   <frame tileid="319" duration="100"/>
  </animation>
 </tile>
 <tile id="313">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_2.png"/>
 </tile>
 <tile id="314">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_3.png"/>
 </tile>
 <tile id="315">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_4.png"/>
 </tile>
 <tile id="316">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_5.png"/>
 </tile>
 <tile id="317">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_6.png"/>
 </tile>
 <tile id="318">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_7.png"/>
 </tile>
 <tile id="319">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_8.png"/>
 </tile>
 <tile id="320">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_9.png"/>
  <animation>
   <frame tileid="320" duration="100"/>
   <frame tileid="321" duration="100"/>
   <frame tileid="322" duration="100"/>
   <frame tileid="323" duration="100"/>
   <frame tileid="324" duration="100"/>
   <frame tileid="325" duration="100"/>
   <frame tileid="326" duration="100"/>
   <frame tileid="327" duration="100"/>
   <frame tileid="328" duration="100"/>
   <frame tileid="329" duration="100"/>
   <frame tileid="330" duration="100"/>
   <frame tileid="331" duration="100"/>
  </animation>
 </tile>
 <tile id="321">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_10.png"/>
 </tile>
 <tile id="322">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_11.png"/>
 </tile>
 <tile id="323">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning_12.png"/>
 </tile>
 <tile id="324">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_1.png"/>
 </tile>
 <tile id="325">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_2.png"/>
 </tile>
 <tile id="326">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_3.png"/>
 </tile>
 <tile id="327">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_4.png"/>
 </tile>
 <tile id="328">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_5.png"/>
 </tile>
 <tile id="329">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_6.png"/>
 </tile>
 <tile id="330">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_7.png"/>
 </tile>
 <tile id="331">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-burning2_8.png"/>
 </tile>
 <tile id="332">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_1.png"/>
  <animation>
   <frame tileid="332" duration="100"/>
   <frame tileid="333" duration="100"/>
   <frame tileid="334" duration="100"/>
   <frame tileid="335" duration="100"/>
   <frame tileid="336" duration="100"/>
   <frame tileid="337" duration="100"/>
   <frame tileid="338" duration="100"/>
   <frame tileid="339" duration="100"/>
   <frame tileid="340" duration="100"/>
   <frame tileid="341" duration="100"/>
   <frame tileid="342" duration="100"/>
   <frame tileid="343" duration="100"/>
   <frame tileid="344" duration="100"/>
   <frame tileid="345" duration="100"/>
   <frame tileid="346" duration="100"/>
   <frame tileid="347" duration="100"/>
   <frame tileid="348" duration="100"/>
   <frame tileid="349" duration="100"/>
  </animation>
 </tile>
 <tile id="333">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_2.png"/>
 </tile>
 <tile id="334">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_3.png"/>
 </tile>
 <tile id="335">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_4.png"/>
 </tile>
 <tile id="336">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_5.png"/>
 </tile>
 <tile id="337">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_6.png"/>
 </tile>
 <tile id="338">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_7.png"/>
 </tile>
 <tile id="339">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_8.png"/>
 </tile>
 <tile id="340">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_9.png"/>
 </tile>
 <tile id="341">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_10.png"/>
 </tile>
 <tile id="342">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_11.png"/>
 </tile>
 <tile id="343">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_12.png"/>
 </tile>
 <tile id="344">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_13.png"/>
 </tile>
 <tile id="345">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_14.png"/>
 </tile>
 <tile id="346">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_15.png"/>
 </tile>
 <tile id="347">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_16.png"/>
 </tile>
 <tile id="348">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_17.png"/>
 </tile>
 <tile id="349">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/torch-smoking_18.png"/>
 </tile>
 <tile id="350">
  <image width="128" height="128" source="../../Props/atlas props - individual sprites/generic light_1.png"/>
  <animation>
   <frame tileid="350" duration="100"/>
   <frame tileid="351" duration="100"/>
   <frame tileid="352" duration="100"/>
   <frame tileid="353" duration="100"/>
  </animation>
 </tile>
 <tile id="351">
  <image width="128" height="128" source="../../Props/atlas props - individual sprites/generic light_2.png"/>
 </tile>
 <tile id="352">
  <image width="128" height="128" source="../../Props/atlas props - individual sprites/generic light_3.png"/>
 </tile>
 <tile id="353">
  <image width="128" height="128" source="../../Props/atlas props - individual sprites/generic light_4.png"/>
 </tile>
 <tile id="354">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_1.png"/>
  <animation>
   <frame tileid="354" duration="100"/>
   <frame tileid="355" duration="100"/>
   <frame tileid="356" duration="100"/>
   <frame tileid="357" duration="100"/>
   <frame tileid="358" duration="100"/>
   <frame tileid="359" duration="100"/>
   <frame tileid="360" duration="100"/>
   <frame tileid="361" duration="100"/>
  </animation>
 </tile>
 <tile id="355">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_2.png"/>
 </tile>
 <tile id="356">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_3.png"/>
 </tile>
 <tile id="357">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_4.png"/>
 </tile>
 <tile id="358">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_5.png"/>
 </tile>
 <tile id="359">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_6.png"/>
 </tile>
 <tile id="360">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_7.png"/>
 </tile>
 <tile id="361">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candleTorch_light_8.png"/>
 </tile>
 <tile id="362">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_1.png"/>
  <animation>
   <frame tileid="362" duration="100"/>
   <frame tileid="363" duration="100"/>
   <frame tileid="364" duration="100"/>
   <frame tileid="365" duration="100"/>
   <frame tileid="366" duration="100"/>
   <frame tileid="367" duration="100"/>
   <frame tileid="368" duration="100"/>
   <frame tileid="369" duration="100"/>
  </animation>
 </tile>
 <tile id="363">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_2.png"/>
 </tile>
 <tile id="364">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_3.png"/>
 </tile>
 <tile id="365">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_4.png"/>
 </tile>
 <tile id="366">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_5.png"/>
 </tile>
 <tile id="367">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_6.png"/>
 </tile>
 <tile id="368">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_7.png"/>
 </tile>
 <tile id="369">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only fire_8.png"/>
 </tile>
 <tile id="370">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_1.png"/>
  <animation>
   <frame tileid="370" duration="100"/>
   <frame tileid="371" duration="100"/>
   <frame tileid="372" duration="100"/>
   <frame tileid="373" duration="100"/>
   <frame tileid="374" duration="100"/>
   <frame tileid="375" duration="100"/>
   <frame tileid="376" duration="100"/>
   <frame tileid="377" duration="100"/>
   <frame tileid="378" duration="100"/>
   <frame tileid="379" duration="100"/>
   <frame tileid="380" duration="100"/>
   <frame tileid="381" duration="100"/>
   <frame tileid="382" duration="100"/>
   <frame tileid="383" duration="100"/>
   <frame tileid="384" duration="100"/>
   <frame tileid="385" duration="100"/>
   <frame tileid="386" duration="100"/>
   <frame tileid="387" duration="100"/>
  </animation>
 </tile>
 <tile id="371">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_2.png"/>
 </tile>
 <tile id="372">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_3.png"/>
 </tile>
 <tile id="373">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_4.png"/>
 </tile>
 <tile id="374">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_5.png"/>
 </tile>
 <tile id="375">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_6.png"/>
 </tile>
 <tile id="376">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_7.png"/>
 </tile>
 <tile id="377">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_8.png"/>
 </tile>
 <tile id="378">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_9.png"/>
 </tile>
 <tile id="379">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_10.png"/>
 </tile>
 <tile id="380">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_11.png"/>
 </tile>
 <tile id="381">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_12.png"/>
 </tile>
 <tile id="382">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_13.png"/>
 </tile>
 <tile id="383">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_14.png"/>
 </tile>
 <tile id="384">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_15.png"/>
 </tile>
 <tile id="385">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_16.png"/>
 </tile>
 <tile id="386">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_17.png"/>
 </tile>
 <tile id="387">
  <image width="64" height="64" source="../../Props/atlas props - individual sprites/candle-only smoke_18.png"/>
 </tile>
</tileset>
